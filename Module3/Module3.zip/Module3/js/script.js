(function(){
    "use strict";
/*
    Nav menu item click rollup menu on mobile
    by: Franciscus Agnew
    source: http://stackoverflow.com/questions/16680543/hide-twitter-bootstrap-nav-collapse-on-click
*/
$('.nav a').click(function() {
    $('.navbar-collapse').collapse('hide');
});

})();